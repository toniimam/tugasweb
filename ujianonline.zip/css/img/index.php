<?PHP
header('location:..');
?>